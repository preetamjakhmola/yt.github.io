﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using YoutubeVideo.Models;
namespace YoutubeVideo.Controllers
{
    public class HomeController : Controller
    {

        public ActionResult Home()
        {   
            return View();
        }

        [HttpPost]
        public ActionResult Home(string url = "")
        {
            if (url == "")
            {
                url = "https://www.youtube.com/watch?v=5gBeLN2Jkng";
            }
            string[] queries = { url };
            List<Models.YoutubeVideo> list = Models.YoutubeVideoLib.TestVideoLib(queries);
            return Json(list);
        }


        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}