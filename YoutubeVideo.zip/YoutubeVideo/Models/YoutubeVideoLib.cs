﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using VideoLibrary;

namespace YoutubeVideo.Models
{
    public class YoutubeVideoLib
    {
        public static List<YoutubeVideo> TestVideoLib(string[] queries)
        {
            List<YoutubeVideo> list = new List<YoutubeVideo>();
            using (var cli = Client.For(YouTube.Default))
            {
                // Console.WriteLine("Downloading...");
                for (int i = 0; i < queries.Length; i++)
                {
                    string uri = queries[i];

                    try
                    {
                        var videoInfos = cli.GetAllVideosAsync(uri).GetAwaiter().GetResult();

                        //Console.WriteLine($"Link #{i + 1}");

                        foreach (var v in videoInfos)
                        {
                            list.Add(new YoutubeVideo { id = $"Link #{i + 1}", title = v.Title, fullName = v.FullName, url = v.Uri, format = v.FileExtension });
                            // Console.WriteLine(v.Uri);
                            // Console.WriteLine();
                        }
                    }
                    catch
                    {
                        Debugger.Break();
                    }
                }
            }
            return list;
        }

    }

    public class YoutubeVideo
    {
        public string id { get; set; }
        public string title { get; set; }
        public string fullName { get; set; }
        public string url { get; set; }
        public string format { get; set; }

    }
}